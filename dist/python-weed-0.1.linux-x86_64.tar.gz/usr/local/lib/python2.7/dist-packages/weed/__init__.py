from .version import VERSION, __version__

import conf, util, master, volume

__author__ = 'darkdarkfruit'
