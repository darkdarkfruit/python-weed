from .version import VERSION, __version__


__author__ = 'darkdarkfruit'
